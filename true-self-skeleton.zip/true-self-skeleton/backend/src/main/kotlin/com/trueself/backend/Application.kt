package com.trueself.backend

import io.ktor.server.application.*
import io.ktor.server.engine.embeddedServer
import io.ktor.server.netty.Netty
import io.ktor.server.plugins.callloging.*
import io.ktor.server.plugins.contentnegotiation.*
import io.ktor.serialization.kotlinx.json.*
import io.ktor.server.routing.*
import io.ktor.http.*
import io.ktor.server.response.*
import io.ktor.server.request.*

import com.trueself.backend.routes.registerStoryRoutes
import com.trueself.backend.routes.registerAnalyticsRoutes

/**
 * 애플리케이션 진입점. Ktor 서버를 설정하고 모든 라우트를 등록합니다.
 */
fun main() {
    embeddedServer(Netty, port = 8080) {
        install(CallLogging)
        install(ContentNegotiation) {
            json()
        }
        routing {
            registerStoryRoutes()
            registerAnalyticsRoutes()
        }
    }.start(wait = true)
}
