package com.trueself.backend.routes

import io.ktor.server.application.*
import io.ktor.server.response.*
import io.ktor.server.routing.*
import io.ktor.http.*

/**
 * Analytics API 라우팅을 정의합니다. 데이터 집계 로직은 구현되지 않았으며,
 * 현재는 샘플 응답을 반환합니다.
 */
fun Route.registerAnalyticsRoutes() {
    route("/analytics/{storyId}") {
        /**
         * 선택 비율 조회
         */
        get("/choices") {
            val storyId = call.parameters["storyId"] ?: return@get call.respond(HttpStatusCode.BadRequest)
            val nodeKey = call.request.queryParameters["nodeKey"]
            val interval = call.request.queryParameters["interval"] ?: "day"
            // TODO: fetch aggregated choice data from database
            call.respond(HttpStatusCode.OK, mapOf(
                "storyId" to storyId,
                "nodeKey" to nodeKey,
                "interval" to interval,
                "data" to emptyList<Any>()
            ))
        }
        /**
         * 퍼널/이탈률 조회
         */
        get("/funnel") {
            val storyId = call.parameters["storyId"] ?: return@get call.respond(HttpStatusCode.BadRequest)
            // TODO: compute funnel data
            call.respond(HttpStatusCode.OK, mapOf(
                "storyId" to storyId,
                "nodes" to emptyList<Any>()
            ))
        }
        /**
         * 감정 트렌드 조회
         */
        get("/emotion-trends") {
            val storyId = call.parameters["storyId"] ?: return@get call.respond(HttpStatusCode.BadRequest)
            val interval = call.request.queryParameters["interval"] ?: "day"
            // TODO: compute emotion trends
            call.respond(HttpStatusCode.OK, mapOf(
                "storyId" to storyId,
                "interval" to interval,
                "data" to emptyList<Any>()
            ))
        }
        /**
         * 요약 통계 조회
         */
        get("/summary") {
            val storyId = call.parameters["storyId"] ?: return@get call.respond(HttpStatusCode.BadRequest)
            // TODO: compute summary stats
            call.respond(HttpStatusCode.OK, mapOf(
                "storyId" to storyId,
                "totalSessions" to 0,
                "repeatPlayers" to 0,
                "avgPlayTimeSeconds" to 0,
                "avgNodesVisited" to 0
            ))
        }
    }
}
