package com.trueself.backend.routes

import io.ktor.server.application.*
import io.ktor.server.routing.*
import io.ktor.server.response.*
import io.ktor.server.request.*
import io.ktor.http.*
import kotlinx.serialization.Serializable

/**
 * 스토리 CRUD 및 플레이 관련 API를 정의합니다. 실제 DB 연동은 향후 구현이 필요합니다.
 */
fun Route.registerStoryRoutes() {
    route("/stories") {
        /**
         * 모든 스토리 목록을 반환합니다. 
         * TODO: 페이지네이션, 검색, 권한 필터 등을 추가하세요.
         */
        get {
            call.respond(HttpStatusCode.OK, mapOf("message" to "List of stories (not implemented yet)"))
        }
        /**
         * 새 스토리를 생성합니다. 본문에는 JSON 스토리 스키마가 전달됩니다.
         */
        post {
            val body = call.receiveText()
            // TODO: validate and persist story
            call.respond(HttpStatusCode.Created, mapOf("message" to "Story created", "body" to body))
        }
        /**
         * 스토리 조회
         */
        get("/{id}") {
            val id = call.parameters["id"] ?: return@get call.respond(HttpStatusCode.BadRequest)
            // TODO: retrieve story by id
            call.respond(HttpStatusCode.OK, mapOf("id" to id, "story" to null))
        }
        /**
         * 스토리 업데이트
         */
        put("/{id}") {
            val id = call.parameters["id"] ?: return@put call.respond(HttpStatusCode.BadRequest)
            val body = call.receiveText()
            // TODO: update story
            call.respond(HttpStatusCode.OK, mapOf("message" to "Story $id updated", "body" to body))
        }
    }
}
