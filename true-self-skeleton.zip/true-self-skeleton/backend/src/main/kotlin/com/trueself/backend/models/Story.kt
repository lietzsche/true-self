package com.trueself.backend.models

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/**
 * 스토리를 구성하는 기본 데이터 모델입니다. 
 * 프론트엔드에서 사용하는 JSON 형식과 대응하기 위해 직렬화 어노테이션을 사용합니다.
 */
@Serializable
data class Story(
    val id: String,
    val title: String,
    val description: String,
    val nodes: List<Node>,
    val edges: List<Edge>
)

@Serializable
data class Node(
    val id: String,
    val type: String,
    val data: NodeData,
    val position: Position
)

@Serializable
data class NodeData(
    val title: String? = null,
    val text: String? = null,
    val choices: List<Choice>? = null,
    val emotionTags: Map<String, Double>? = null
)

@Serializable
data class Choice(
    val label: String,
    val target: String,
    val condition: Map<String, String>? = null
)

@Serializable
data class Position(
    val x: Double,
    val y: Double
)

@Serializable
data class Edge(
    val id: String,
    val source: String,
    val target: String,
    val label: String,
    val condition: Map<String, String>? = null
)
