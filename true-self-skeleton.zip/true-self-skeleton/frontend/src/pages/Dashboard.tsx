import React, { useEffect } from 'react';
import { LineChart, Line, CartesianGrid, XAxis, YAxis, Tooltip, Legend, ResponsiveContainer, BarChart, Bar } from 'recharts';
import { useQuery } from '@tanstack/react-query';

// 간단한 fetcher 함수
const fetchSummary = async () => {
  const res = await fetch('/api/analytics/demo-story/summary');
  if (!res.ok) throw new Error('Failed to fetch summary');
  return res.json();
};

/**
 * 대시보드 페이지. 선택 비율, 감정 트렌드 등 여러 차트를 표시하기 위해 Recharts 컴포넌트를 사용합니다.
 * 현재는 예제 데이터와 기본 API 호출만 포함됩니다.
 */
const Dashboard: React.FC = () => {
  // Summary 데이터를 가져옵니다.
  const { data: summaryData, isLoading: summaryLoading } = useQuery(['summary'], fetchSummary);

  // 예제 데이터: 감정 트렌드
  const emotionData = [
    { date: '07-01', joy: 0.6, sadness: 0.2, anger: 0.05, fear: 0.15 },
    { date: '07-02', joy: 0.55, sadness: 0.25, anger: 0.1, fear: 0.1 },
    { date: '07-03', joy: 0.5, sadness: 0.3, anger: 0.1, fear: 0.1 },
  ];

  return (
    <div className="space-y-8">
      <section>
        <h2 className="text-xl font-semibold mb-2">요약 통계</h2>
        {summaryLoading && <p>로딩 중...</p>}
        {summaryData && (
          <ul className="list-disc ml-5">
            <li>총 세션 수: {summaryData.totalSessions}</li>
            <li>재방문 사용자 수: {summaryData.repeatPlayers}</li>
            <li>평균 플레이 시간: {summaryData.avgPlayTimeSeconds}초</li>
            <li>평균 방문 노드 수: {summaryData.avgNodesVisited}</li>
          </ul>
        )}
      </section>

      <section>
        <h2 className="text-xl font-semibold mb-2">감정 트렌드 예제</h2>
        <div className="w-full h-64">
          <ResponsiveContainer>
            <LineChart data={emotionData} margin={{ top: 5, right: 20, bottom: 5, left: 0 }}>
              <Line type="monotone" dataKey="joy" stroke="#8884d8" name="Joy" />
              <Line type="monotone" dataKey="sadness" stroke="#82ca9d" name="Sadness" />
              <Line type="monotone" dataKey="anger" stroke="#ffc658" name="Anger" />
              <Line type="monotone" dataKey="fear" stroke="#ff7300" name="Fear" />
              <CartesianGrid stroke="#ccc" strokeDasharray="5 5" />
              <XAxis dataKey="date" label={{ value: '날짜', position: 'insideBottomRight', offset: 0 }} />
              <YAxis label={{ value: '점수', angle: -90, position: 'insideLeft' }} />
              <Tooltip />
              <Legend />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </section>
    </div>
  );
};

export default Dashboard;
