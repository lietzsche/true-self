import React from 'react';
import ReactFlow, { useNodesState, useEdgesState, Controls } from 'reactflow';
import 'reactflow/dist/style.css';

/**
 * 스토리 그래프 에디터 페이지. 기본적인 ReactFlow 캔버스를 초기화합니다.
 */
const Editor: React.FC = () => {
  const [nodes, , onNodesChange] = useNodesState([]);
  const [edges, , onEdgesChange] = useEdgesState([]);

  return (
    <div style={{ width: '100%', height: '80vh' }} className="border rounded">
      <ReactFlow
        nodes={nodes}
        edges={edges}
        onNodesChange={onNodesChange}
        onEdgesChange={onEdgesChange}
        fitView
      >
        <Controls />
      </ReactFlow>
      <p className="mt-2 text-sm text-gray-500">노드를 추가하려면 캔버스를 두 번 클릭하세요. 이 스켈레톤은 기본 인터랙션만 제공합니다.</p>
    </div>
  );
};

export default Editor;
