import React from 'react';
import { Routes, Route, Link } from 'react-router-dom';
import Editor from './pages/Editor';
import Dashboard from './pages/Dashboard';

/**
 * 애플리케이션 루트 컴포넌트. 간단한 네비게이션과 라우팅을 제공합니다.
 */
const App: React.FC = () => {
  return (
    <div className="h-full flex flex-col">
      <nav className="bg-gray-800 text-white p-4 flex justify-between">
        <h1 className="font-bold">true‑self</h1>
        <div className="space-x-4">
          <Link to="/" className="hover:underline">스토리 에디터</Link>
          <Link to="/dashboard" className="hover:underline">대시보드</Link>
        </div>
      </nav>
      <main className="flex-1 overflow-auto p-4">
        <Routes>
          <Route path="/" element={<Editor />} />
          <Route path="/dashboard" element={<Dashboard />} />
        </Routes>
      </main>
    </div>
  );
};

export default App;
