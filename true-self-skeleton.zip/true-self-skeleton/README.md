# true‑self 프로젝트 스켈레톤

이 저장소는 **true‑self** 프로젝트의 기본 스켈레톤입니다. 철학·심리 대화 게임을 통해 사용자가 자기 탐색을 경험하도록 돕는 웹 애플리케이션을 구축하기 위한 구조를 제공합니다.

## 구성 개요

* `backend/` – Ktor 3(Kotlin) 기반 서버 코드. 스토리 JSON을 관리하고 Analytics 엔드포인트(`/analytics/**`)를 제공합니다.
* `frontend/` – React 18 + Vite + TypeScript로 작성된 클라이언트 애플리케이션. ReactFlow를 이용한 스토리 그래프 에디터와 Recharts 기반 대시보드가 포함됩니다.
* `helm/` – Kubernetes 배포를 위한 Helm 차트. backend, frontend 서비스 및 관련 설정을 정의합니다.
* `infra/` – 인프라 스크립트 및 예제 설정. 필요에 따라 Dockerfile, CI 구성 등을 추가할 수 있습니다.
* `docs/` – ERD, JSON 스토리 스키마, Analytics 설계 등 문서화된 자료를 제공합니다.

## 실행 방법

### 요구 사항

* **Java 17** 이상
* **Kotlin 1.9**
* **Node.js 18** 이상
* **PostgreSQL** (TimescaleDB 확장 포함)

### 백엔드 실행

```bash
cd backend
./gradlew run
```

`Application.kt` 모듈은 기본 HTTP 서버를 실행하며 `/stories`, `/stories/{id}` 등 스토리 관련 엔드포인트와 `/analytics/**` 엔드포인트를 제공합니다. 데이터베이스 접속 정보는 `application.conf`에서 설정할 수 있습니다.

### 프론트엔드 실행

```bash
cd frontend
npm install
npm run dev
```

Vite 개발 서버가 실행되며 기본 포트(예: 5173)에서 애플리케이션을 미리 볼 수 있습니다. 스토리 그래프 에디터, 감정 분석 결과 표시, 대시보드 페이지는 모두 이 프로젝트에 포함된 기본 컴포넌트들입니다.

### Helm 배포

`helm/` 디렉터리에는 backend 및 frontend를 Kubernetes에 배포하기 위한 기본 Chart가 포함되어 있습니다. 실제 배포에서는 `values.yaml`을 수정해 이미지 이름, 환경 변수, 리소스 설정 등을 정의합니다.

```bash
helm install true-self ./helm
```

## 문서

* `docs/ERD.md` – 주요 도메인 테이블과 관계를 설명합니다.
* `docs/story_schema.md` – JSON 스토리 스키마 정의입니다.
* `docs/analytics_api.md` – Analytics API 및 지표 설계.

## 향후 작업

이 스켈레톤은 기반 구조만을 제공합니다. 실제 제품화 과정에서는 인증/권한 처리, ONNX 감정 모델 통합, TimescaleDB 기반 Materialized View 구현, 대시보드 차트 완성 등을 포함하여 기능을 확장해야 합니다.
