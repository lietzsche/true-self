# Analytics 설계 및 API

본 문서에서는 관리자 및 스토리 작성자를 위한 대시보드 지표와 해당 데이터를 제공하는 REST API를 정의합니다. Analytics 데이터는 `story_logs`와 `story_sessions` 테이블을 기반으로 하며, TimescaleDB의 Continuous Aggregate 또는 Materialized View를 통해 집계될 수 있습니다.

## 핵심 지표

| 지표 | 설명 | 예시 API |
|-----|-----|---------|
| **분기별 선택 비율** | 특정 노드에서 각 선택지가 얼마나 선택됐는지, 분기(Quarter) 단위로 계산합니다. | `GET /analytics/{storyId}/choices?nodeKey=start&interval=quarter` |
| **노드 이탈률(Funnel)** | 스토리 진행 과정에서 어느 지점에서 사용자가 떠나는지. 특정 노드별 세션 수 대비 다음 노드로 이동한 비율을 계산합니다. | `GET /analytics/{storyId}/funnel` |
| **감정 트렌드** | 플레이 중 감정 분석 결과의 시간적 변화를 표시합니다. 선형 그래프 혹은 히트맵 형태로 시각화할 수 있습니다. | `GET /analytics/{storyId}/emotion-trends?interval=day` |
| **세션·재방문·평균 플레이 시간** | 스토리의 전체 세션 수, 재방문 사용자 수, 평균 플레이 시간 등의 요약 통계입니다. | `GET /analytics/{storyId}/summary` |

## API 정의

모든 Analytics 엔드포인트는 인증된 사용자(관리자 또는 해당 스토리 작성자)만 접근할 수 있습니다. 응답 형식은 JSON입니다.

### GET `/analytics/{storyId}/choices`

특정 노드에서 사용자들이 선택한 선택지 비율을 시간 단위별로 제공합니다.

**쿼리 파라미터**

| 파라미터 | 필수 | 설명 |
|---------|----|-----|
| `nodeKey` | ✅ | 분석할 노드의 키(ID) |
| `interval` | ❌ | 집계 단위. `hour`, `day`, `week`, `month`, `quarter` 중 선택. 기본값은 `day`. |

**예시 응답**

```json
{
  "storyId": "story-123",
  "nodeKey": "start",
  "interval": "quarter",
  "data": [
    {
      "period": "2025-Q1",
      "choices": [
        { "label": "왼쪽 길", "count": 120 },
        { "label": "오른쪽 길", "count": 80 }
      ]
    },
    {
      "period": "2025-Q2",
      "choices": [
        { "label": "왼쪽 길", "count": 90 },
        { "label": "오른쪽 길", "count": 110 }
      ]
    }
  ]
}
```

### GET `/analytics/{storyId}/funnel`

스토리 전체의 노드별 진입/이탈 비율을 제공합니다. 특정 세션에서 사용자가 노드를 방문한 후 다음 노드로 이동한 비율을 계산하여, 이탈률이 높은 부분을 파악합니다.

**예시 응답**

```json
{
  "storyId": "story-123",
  "nodes": [
    { "nodeKey": "start", "visits": 200, "dropOff": 0.1 },
    { "nodeKey": "leftPath", "visits": 100, "dropOff": 0.05 },
    { "nodeKey": "rightPath", "visits": 100, "dropOff": 0.2 }
  ]
}
```

### GET `/analytics/{storyId}/emotion-trends`

감정 분석 결과의 시간적 변화를 반환합니다. 그래프나 히트맵으로 시각화하기 위해 감정별 점수를 포함합니다.

**쿼리 파라미터**

| 파라미터 | 필수 | 설명 |
|---------|----|-----|
| `interval` | ❌ | 집계 단위(`hour`, `day`, `week`) |

**예시 응답**

```json
{
  "storyId": "story-123",
  "interval": "day",
  "data": [
    {
      "date": "2025-07-01",
      "emotions": { "joy": 0.6, "sadness": 0.2, "anger": 0.05, "fear": 0.15 }
    },
    {
      "date": "2025-07-02",
      "emotions": { "joy": 0.55, "sadness": 0.25, "anger": 0.1, "fear": 0.1 }
    }
  ]
}
```

### GET `/analytics/{storyId}/summary`

세션 수, 재방문 수, 평균 플레이 시간과 같은 요약 통계를 반환합니다.

**예시 응답**

```json
{
  "storyId": "story-123",
  "totalSessions": 250,
  "repeatPlayers": 40,
  "avgPlayTimeSeconds": 300,
  "avgNodesVisited": 10
}
```

위 API들은 기본 설계를 위한 예시이며, 실제 구현 시 필요에 따라 필드를 확장하거나 GraphQL 형태로 제공할 수 있습니다.
