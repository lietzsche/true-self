# 데이터베이스 ERD

본 프로젝트는 PostgresQL(+TimescaleDB) 기반으로 설계되었습니다. 아래는 핵심 도메인 테이블과 관계를 요약한 것입니다. 실제 구현 시 세부 컬럼이나 제약 조건은 추가 조정될 수 있습니다.

## 테이블 목록

| 테이블 | 설명 |
|-------|-----|
| `users` | 서비스 사용자 정보. 관리자(admin), 스토리 작성자(author), 일반 플레이어(player) 역할을 구분합니다. |
| `stories` | 각 스토리의 메타데이터. 제목, 슬러그, 설명, 공개 여부 등을 저장합니다. |
| `story_nodes` | 스토리 내 노드 정의. 노드 종류(text, choice, end 등), 내용, 부가 메타데이터를 포함합니다. |
| `story_edges` | 노드 간의 연결을 정의하는 간선. 선택지 텍스트와 조건 등을 포함합니다. |
| `story_sessions` | 사용자가 스토리를 플레이하는 세션을 기록합니다. 익명 사용자의 경우 `user_id`는 `NULL`일 수 있습니다. |
| `story_logs` | 한 세션 안에서의 노드 방문 및 선택 로그. 감정 분석 결과 등도 저장됩니다. |
| `emotions` | (옵션) 감정 분석 결과를 정규화해 저장하는 테이블. 세션, 노드, 시간대별 감정 추세를 분석하기 위해 사용될 수 있습니다. |

### `users`

| 컬럼 | 타입 | 설명 |
|------|------|-----|
| `id` | `UUID PK` | 사용자 식별자 |
| `username` | `VARCHAR(50)` | 고유 사용자명 |
| `email` | `VARCHAR(255)` | 이메일 주소 |
| `password_hash` | `VARCHAR(255)` | 해시된 비밀번호 |
| `role` | `VARCHAR(10)` | `admin`, `author`, `player` 중 하나 |
| `created_at` | `TIMESTAMPTZ` | 생성 시각 |

### `stories`

| 컬럼 | 타입 | 설명 |
|------|------|-----|
| `id` | `UUID PK` | 스토리 식별자 |
| `author_id` | `UUID FK -> users.id` | 작성자 |
| `title` | `VARCHAR(100)` | 스토리 제목 |
| `slug` | `VARCHAR(100)` | URL에 사용되는 슬러그 |
| `description` | `TEXT` | 스토리 설명 |
| `is_public` | `BOOLEAN` | 공개 여부 |
| `created_at` | `TIMESTAMPTZ` | 작성 시각 |
| `updated_at` | `TIMESTAMPTZ` | 수정 시각 |

### `story_nodes`

| 컬럼 | 타입 | 설명 |
|------|------|-----|
| `id` | `UUID PK` | 내부 식별자 |
| `story_id` | `UUID FK -> stories.id` | 스토리 참조 |
| `node_key` | `VARCHAR(100)` | JSON 스토리 내 노드 키(ID) |
| `node_type` | `VARCHAR(20)` | `text`, `choice`, `end` 등 |
| `content` | `TEXT` | 대화 텍스트 또는 설명 |
| `metadata` | `JSONB` | 감정 분석 태그, 다음 노드 조건 등 메타데이터 |

### `story_edges`

| 컬럼 | 타입 | 설명 |
|------|------|-----|
| `id` | `UUID PK` | 내부 식별자 |
| `story_id` | `UUID FK -> stories.id` |
| `source_node_key` | `VARCHAR(100)` | 출발 노드 키 |
| `target_node_key` | `VARCHAR(100)` | 도착 노드 키 |
| `label` | `VARCHAR(255)` | 선택지 텍스트 |
| `condition` | `JSONB` | 특정 조건(보유 태그, 이전 선택 등)에 따라 활성화되는지 여부 |

### `story_sessions`

| 컬럼 | 타입 | 설명 |
|------|------|-----|
| `id` | `UUID PK` | 세션 식별자 |
| `story_id` | `UUID FK -> stories.id` |
| `user_id` | `UUID FK -> users.id` | NULL 가능 |
| `started_at` | `TIMESTAMPTZ` | 플레이 시작 시각 |
| `completed_at` | `TIMESTAMPTZ` | 완료 시각 (미완료 시 NULL) |
| `duration_seconds` | `INT` | 플레이 시간(초) |

### `story_logs`

| 컬럼 | 타입 | 설명 |
|------|------|-----|
| `id` | `UUID PK` |
| `session_id` | `UUID FK -> story_sessions.id` |
| `node_key` | `VARCHAR(100)` | 방문한 노드 키 |
| `edge_label` | `VARCHAR(255)` | 선택한 선택지 텍스트(없다면 NULL) |
| `emotion` | `JSONB` | 감정 분석 결과 (예: `{ "joy": 0.8, "anger": 0.1, ... }`) |
| `created_at` | `TIMESTAMPTZ` | 이벤트 발생 시각 |

TimescaleDB 확장을 활용하면 `story_logs`에 시간 파티셔닝을 적용하여 고속 시계열 쿼리가 가능합니다. 더 복잡한 조회를 위해 `story_logs`를 기반으로 하는 Materialized View 또는 Continuous Aggregate를 생성해 분기별 선택 비율, 노드 이탈률, 감정 트렌드를 계산할 수 있습니다.
