# JSON 스토리 스키마

스토리는 프론트엔드에서 사용하기 위해 JSON 형식으로 저장되며, 각 스토리는 `nodes`와 `edges` 두 가지 구성 요소로 이루어집니다. 이 구조는 ReactFlow 그래프 에디터와 호환되도록 설계되었습니다.

## 최상위 구조

```json
{
  "id": "uuid",          // 스토리 고유 ID
  "title": "string",      // 스토리 제목
  "description": "string", // 스토리 설명
  "nodes": [ ... ],        // 노드 목록
  "edges": [ ... ]         // 간선 목록
}
```

## 노드(`nodes`) 객체

각 노드는 다음 속성을 가집니다. 필요 시 추가 필드를 자유롭게 확장할 수 있습니다.

| 속성 | 타입 | 필수 | 설명 |
|-----|-----|----|-----|
| `id` | `string` | ✅ | 노드 식별자. ReactFlow에서 고유해야 합니다. |
| `type` | `string` | ✅ | 노드 타입. `text`, `choice`, `end` 등. 타입에 따라 UI 구성 요소가 달라집니다. |
| `data` | `object` | ✅ | 노드의 실제 내용과 메타데이터를 담는 객체. |
| `position` | `{ x: number, y: number }` | ✅ | 그래프 에디터에서 노드의 위치. |

`data` 객체에는 다음과 같은 필드를 포함할 수 있습니다.

| 필드 | 설명 |
|----|-----|
| `title` | 노드 제목. 간단한 요약이나 질문을 표시할 때 사용합니다. |
| `text` | 노드 본문. 대화 내용이나 설명 등을 포함합니다. |
| `choices` | 선택지 목록. 각 요소는 `{ "label": "선택지 텍스트", "target": "다음 노드 id", "condition": {...} }` 형태를 가집니다. |
| `emotionTags` | (옵션) 예상되는 감정 레이블 또는 감정 분석을 위한 힌트입니다. |

## 간선(`edges`) 객체

간선은 노드 간의 연결을 정의하며 다음 속성을 가집니다.

| 속성 | 타입 | 필수 | 설명 |
|----|----|----|-----|
| `id` | `string` | ✅ | 간선 식별자. 고유해야 합니다. |
| `source` | `string` | ✅ | 출발 노드의 `id` |
| `target` | `string` | ✅ | 도착 노드의 `id` |
| `label` | `string` | ✅ | 간선 라벨. 선택지 텍스트를 의미합니다. |
| `condition` | `object` | ❌ | 특정 상태(이전 선택, 플래그 등)에 따라 간선이 활성화될 조건을 나타냅니다. |

## 예시

```json
{
  "id": "story-123",
  "title": "모험의 시작",
  "description": "간단한 예제 스토리",
  "nodes": [
    {
      "id": "start",
      "type": "text",
      "data": {
        "title": "안내자",
        "text": "당신은 어두운 숲 속에서 깨어납니다. 어디로 향하시겠습니까?",
        "choices": [
          { "label": "왼쪽 길", "target": "leftPath" },
          { "label": "오른쪽 길", "target": "rightPath" }
        ]
      },
      "position": { "x": 0, "y": 0 }
    },
    {
      "id": "leftPath",
      "type": "end",
      "data": {
        "title": "왼쪽 길의 끝",
        "text": "평화로운 호수가 있는 곳에 도착했습니다."
      },
      "position": { "x": -150, "y": 150 }
    },
    {
      "id": "rightPath",
      "type": "end",
      "data": {
        "title": "오른쪽 길의 끝",
        "text": "무서운 괴물에게 잡히고 말았습니다."
      },
      "position": { "x": 150, "y": 150 }
    }
  ],
  "edges": [
    { "id": "e1", "source": "start", "target": "leftPath", "label": "왼쪽 길" },
    { "id": "e2", "source": "start", "target": "rightPath", "label": "오른쪽 길" }
  ]
}
```

이 스키마를 기반으로 스토리를 생성하고 ReactFlow 그래프 편집기에서 시각적으로 편집할 수 있습니다.
